tips.csv from McKinney (2018) 2nd Edition dataset

TRI.csv from EPA Toxic Release Inventory File for Cook County IL 2018 downloaded from https://enviro.epa.gov/triexplorer/release_fac?P_VIEW=COFA&trilib=TRIQ1&TAB_RPT=1&sort=_VIEW_&Fedcode=&FLD=TRIID&FLD=LNGLAT&FLD=RELLBY&FLD=TSFDSP&sort_fmt=1&industry=ALL&STATE=17&COUNTY=17031&chemical=All+chemicals&YEAR=2018&TopN=ALL